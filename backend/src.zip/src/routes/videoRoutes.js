import express from 'express';
import {
  getAllVideos,
  getVideoById,
  createVideo,
  updateVideo,
  deleteVideo,
  getTrendingVideos,
  getAllTags
} from '../controllers/videoController.js';

const router = express.Router();

// Public routes
router.get('/', getAllVideos);
router.get('/trending', getTrendingVideos);
router.get('/tags', getAllTags);
router.get('/:id', getVideoById);

// Admin routes (add authentication middleware later)
router.post('/', createVideo);
router.put('/:id', updateVideo);
router.delete('/:id', deleteVideo);

export default router;