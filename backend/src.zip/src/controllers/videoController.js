import Video from '../models/Video.js';
import { Op } from 'sequelize';

// Get all videos with filtering, sorting, and pagination
export const getAllVideos = async (req, res) => {
  try {
    const { 
      page = 1, 
      limit = 12, 
      search = '', 
      category = '', 
      sortBy = 'createdAt',
      order = 'DESC',
      tags = ''
    } = req.query;

    // Build where clause
    const where = { isPublished: true };

    // Search by title or description
    if (search) {
      where[Op.or] = [
        { title: { [Op.iLike]: `%${search}%` } },
        { description: { [Op.iLike]: `%${search}%` } }
      ];
    }

    // Filter by category
    if (category && category !== 'all') {
      where.category = category;
    }

    // Filter by tags
    if (tags) {
      const tagArray = tags.split(',').map(tag => tag.trim());
      where.tags = { [Op.overlap]: tagArray };
    }

    // Calculate offset
    const offset = (page - 1) * limit;

    // Execute query
    const { count, rows: videos } = await Video.findAndCountAll({
      where,
      order: [[sortBy, order]],
      limit: parseInt(limit),
      offset: parseInt(offset)
    });

    res.json({
      success: true,
      data: videos,
      pagination: {
        currentPage: Number(page),
        totalPages: Math.ceil(count / limit),
        totalVideos: count,
        hasMore: page * limit < count
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching videos',
      error: error.message
    });
  }
};

// Get single video by ID
export const getVideoById = async (req, res) => {
  try {
    const video = await Video.findByPk(req.params.id);

    if (!video) {
      return res.status(404).json({
        success: false,
        message: 'Video not found'
      });
    }

    // Increment views
    video.views += 1;
    await video.save();

    res.json({
      success: true,
      data: video
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching video',
      error: error.message
    });
  }
};

// Create new video
export const createVideo = async (req, res) => {
  try {
    const video = await Video.create(req.body);

    res.status(201).json({
      success: true,
      message: 'Video created successfully',
      data: video
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: 'Error creating video',
      error: error.message
    });
  }
};

// Update video
export const updateVideo = async (req, res) => {
  try {
    const video = await Video.findByPk(req.params.id);

    if (!video) {
      return res.status(404).json({
        success: false,
        message: 'Video not found'
      });
    }

    await video.update(req.body);

    res.json({
      success: true,
      message: 'Video updated successfully',
      data: video
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: 'Error updating video',
      error: error.message
    });
  }
};

// Delete video
export const deleteVideo = async (req, res) => {
  try {
    const video = await Video.findByPk(req.params.id);

    if (!video) {
      return res.status(404).json({
        success: false,
        message: 'Video not found'
      });
    }

    await video.destroy();

    res.json({
      success: true,
      message: 'Video deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error deleting video',
      error: error.message
    });
  }
};

// Get trending videos
export const getTrendingVideos = async (req, res) => {
  try {
    const videos = await Video.findAll({
      where: { isPublished: true },
      order: [
        ['views', 'DESC'],
        ['createdAt', 'DESC']
      ],
      limit: 10
    });

    res.json({
      success: true,
      data: videos
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching trending videos',
      error: error.message
    });
  }
};

// Get all unique tags
export const getAllTags = async (req, res) => {
  try {
    const videos = await Video.findAll({
      attributes: ['tags'],
      where: { isPublished: true }
    });

    // Flatten and get unique tags
    const allTags = videos
      .flatMap(video => video.tags)
      .filter((tag, index, self) => tag && self.indexOf(tag) === index);

    res.json({
      success: true,
      data: allTags
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching tags',
      error: error.message
    });
  }
};