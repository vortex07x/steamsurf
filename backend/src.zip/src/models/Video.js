import { DataTypes } from 'sequelize';
import { sequelize } from '../config/database.js';

const Video = sequelize.define('Video', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  title: {
    type: DataTypes.STRING(200),
    allowNull: false,
    validate: {
      notEmpty: {
        msg: 'Video title is required'
      },
      len: {
        args: [1, 200],
        msg: 'Title must be between 1 and 200 characters'
      }
    }
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: false,
    validate: {
      notEmpty: {
        msg: 'Description is required'
      },
      len: {
        args: [1, 2000],
        msg: 'Description cannot exceed 2000 characters'
      }
    }
  },
  videoUrl: {
    type: DataTypes.STRING,
    allowNull: false,
    validate: {
      notEmpty: {
        msg: 'Video URL is required'
      }
    }
  },
  thumbnailUrl: {
    type: DataTypes.STRING,
    defaultValue: '/uploads/default-thumbnail.jpg'
  },
  duration: {
    type: DataTypes.INTEGER, // in seconds
    allowNull: false,
    validate: {
      min: 0
    }
  },
  tags: {
    type: DataTypes.ARRAY(DataTypes.STRING),
    defaultValue: []
  },
  category: {
    type: DataTypes.ENUM('Music', 'Tutorial', 'Gaming', 'Vlog', 'Documentary', 'Other'),
    defaultValue: 'Other',
    allowNull: false
  },
  views: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  },
  quality: {
    type: DataTypes.ARRAY(DataTypes.STRING),
    defaultValue: ['720p']
  },
  likes: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  },
  dislikes: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  },
  isPublished: {
    type: DataTypes.BOOLEAN,
    defaultValue: true
  },
  uploadedBy: {
    type: DataTypes.STRING,
    defaultValue: 'Admin'
  }
}, {
  tableName: 'videos',
  timestamps: true, // Adds createdAt and updatedAt
  indexes: [
    {
      fields: ['category']
    },
    {
      fields: ['views']
    },
    {
      fields: ['createdAt']
    }
  ]
});

export default Video;