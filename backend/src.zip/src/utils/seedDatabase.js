import { sequelize } from '../config/database.js';
import Video from '../models/Video.js';
import dotenv from 'dotenv';

dotenv.config();

const sampleVideos = [
  {
    title: "Epic Guitar Solo Performance",
    description: "An amazing guitar solo performance featuring legendary techniques and stunning musicianship.",
    videoUrl: "https://example.com/video1.mp4",
    thumbnailUrl: "https://picsum.photos/seed/video1/640/360",
    duration: 245,
    tags: ["guitar", "music", "rock", "performance"],
    category: "Music",
    quality: ["720p", "1080p"],
    views: 15420,
    likes: 892
  },
  {
    title: "React.js Complete Tutorial 2024",
    description: "Learn React.js from scratch with this comprehensive tutorial covering hooks, components, and modern practices.",
    videoUrl: "https://example.com/video2.mp4",
    thumbnailUrl: "https://picsum.photos/seed/video2/640/360",
    duration: 3600,
    tags: ["react", "javascript", "tutorial", "web development"],
    category: "Tutorial",
    quality: ["720p", "1080p"],
    views: 28340,
    likes: 1523
  },
  {
    title: "Gaming Highlights - Epic Moments",
    description: "The best gaming moments from last month's streaming sessions. Don't miss these incredible plays!",
    videoUrl: "https://example.com/video3.mp4",
    thumbnailUrl: "https://picsum.photos/seed/video3/640/360",
    duration: 720,
    tags: ["gaming", "highlights", "esports"],
    category: "Gaming",
    quality: ["720p", "1080p", "4K"],
    views: 45200,
    likes: 3421
  },
  {
    title: "My Daily Vlog - City Adventures",
    description: "Follow me around the city as I explore new places, meet interesting people, and share my daily adventures.",
    videoUrl: "https://example.com/video4.mp4",
    thumbnailUrl: "https://picsum.photos/seed/video4/640/360",
    duration: 890,
    tags: ["vlog", "daily", "lifestyle", "travel"],
    category: "Vlog",
    quality: ["720p", "1080p"],
    views: 12300,
    likes: 645
  },
  {
    title: "Nature Documentary: Wildlife Wonders",
    description: "Explore the beauty of nature and witness incredible wildlife moments captured in stunning detail.",
    videoUrl: "https://example.com/video5.mp4",
    thumbnailUrl: "https://picsum.photos/seed/video5/640/360",
    duration: 2400,
    tags: ["nature", "documentary", "wildlife", "animals"],
    category: "Documentary",
    quality: ["1080p", "4K"],
    views: 67800,
    likes: 4231
  },
  {
    title: "Cooking Masterclass: Italian Pasta",
    description: "Learn how to make authentic Italian pasta from scratch with this detailed cooking tutorial.",
    videoUrl: "https://example.com/video6.mp4",
    thumbnailUrl: "https://picsum.photos/seed/video6/640/360",
    duration: 1200,
    tags: ["cooking", "food", "tutorial", "italian"],
    category: "Tutorial",
    quality: ["720p", "1080p"],
    views: 34200,
    likes: 2134
  },
  {
    title: "Metal Band Live Concert 2024",
    description: "Full concert recording of an epic metal band performance with incredible energy and stage presence.",
    videoUrl: "https://example.com/video7.mp4",
    thumbnailUrl: "https://picsum.photos/seed/video7/640/360",
    duration: 5400,
    tags: ["metal", "concert", "live", "music", "rock"],
    category: "Music",
    quality: ["1080p"],
    views: 89400,
    likes: 6234
  },
  {
    title: "Fitness Workout Routine - Full Body",
    description: "A complete full-body workout routine you can do at home with minimal equipment.",
    videoUrl: "https://example.com/video8.mp4",
    thumbnailUrl: "https://picsum.photos/seed/video8/640/360",
    duration: 1800,
    tags: ["fitness", "workout", "health", "exercise"],
    category: "Other",
    quality: ["720p", "1080p"],
    views: 23400,
    likes: 1432
  }
];

const seedDatabase = async () => {
  try {
    // Connect to database
    await sequelize.authenticate();
    console.log('✅ Connected to PostgreSQL');

    // Sync database
    await sequelize.sync({ force: true }); // This will drop and recreate tables
    console.log('📊 Database synced');

    // Clear existing videos
    await Video.destroy({ where: {}, truncate: true });
    console.log('🗑️  Cleared existing videos');

    // Insert sample videos
    await Video.bulkCreate(sampleVideos);
    console.log(`✅ Inserted ${sampleVideos.length} sample videos`);

    console.log('🎉 Database seeded successfully!');
    process.exit(0);
  } catch (error) {
    console.error('❌ Error seeding database:', error);
    process.exit(1);
  }
};

seedDatabase();