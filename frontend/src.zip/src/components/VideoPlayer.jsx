import React, { useState, useEffect, useRef } from 'react';
import { 
  Play, Pause, Volume2, VolumeX, Maximize, Minimize, 
  Settings, X 
} from 'lucide-react';
import { formatDuration, formatViews } from '../utils/helpers';

const VideoPlayer = ({ video, onClose, relatedVideos, onVideoSelect }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(1);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const videoRef = useRef(null);
  const containerRef = useRef(null);
  const controlsTimeoutRef = useRef(null);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const handleVolumeChange = (e) => {
    const newVolume = parseFloat(e.target.value);
    setVolume(newVolume);
    if (videoRef.current) {
      videoRef.current.volume = newVolume;
      setIsMuted(newVolume === 0);
    }
  };

  const handleSeek = (e) => {
    const newTime = parseFloat(e.target.value);
    setCurrentTime(newTime);
    if (videoRef.current) {
      videoRef.current.currentTime = newTime;
    }
  };

  const handleSpeedChange = (speed) => {
    setPlaybackSpeed(speed);
    if (videoRef.current) {
      videoRef.current.playbackRate = speed;
    }
    setShowSpeedMenu(false);
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const handleMouseMove = () => {
    setShowControls(true);
    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current);
    }
    controlsTimeoutRef.current = setTimeout(() => {
      if (isPlaying) {
        setShowControls(false);
      }
    }, 3000);
  };

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleTimeUpdate = () => setCurrentTime(video.currentTime);
    const handleLoadedMetadata = () => setDuration(video.duration);
    const handleEnded = () => setIsPlaying(false);

    video.addEventListener('timeupdate', handleTimeUpdate);
    video.addEventListener('loadedmetadata', handleLoadedMetadata);
    video.addEventListener('ended', handleEnded);

    return () => {
      video.removeEventListener('timeupdate', handleTimeUpdate);
      video.removeEventListener('loadedmetadata', handleLoadedMetadata);
      video.removeEventListener('ended', handleEnded);
    };
  }, []);

  useEffect(() => {
    const handleKeyPress = (e) => {
      switch(e.key) {
        case ' ':
          e.preventDefault();
          togglePlay();
          break;
        case 'f':
          toggleFullscreen();
          break;
        case 'm':
          toggleMute();
          break;
        case 'ArrowLeft':
          if (videoRef.current) videoRef.current.currentTime -= 5;
          break;
        case 'ArrowRight':
          if (videoRef.current) videoRef.current.currentTime += 5;
          break;
      }
    };

    document.addEventListener('keydown', handleKeyPress);
    return () => document.removeEventListener('keydown', handleKeyPress);
  }, [isPlaying, isMuted]);

  return (
    <div className="fixed inset-0 bg-black z-50 overflow-y-auto">
      <div className="min-h-screen py-4 px-4">
        <div className="max-w-7xl mx-auto">
          <button
            onClick={onClose}
            className="mb-4 text-white hover:text-primary transition-colors flex items-center gap-2"
          >
            <X size={32} />
            <span className="text-lg">Close</span>
          </button>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <div 
                ref={containerRef} 
                className="relative bg-black rounded-lg overflow-hidden"
                onMouseMove={handleMouseMove}
                onMouseLeave={() => isPlaying && setShowControls(false)}
              >
                <video
                  ref={videoRef}
                  className="w-full"
                  style={{ aspectRatio: '16/9' }}
                  poster={video.thumbnailUrl}
                  onClick={togglePlay}
                >
                  <source src={video.videoUrl} type="video/mp4" />
                </video>

                <div 
                  className={`absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black via-black/80 to-transparent p-4 transition-opacity duration-300 ${
                    showControls ? 'opacity-100' : 'opacity-0'
                  }`}
                >
                  <input
                    type="range"
                    min="0"
                    max={duration || 0}
                    value={currentTime}
                    onChange={handleSeek}
                    className="w-full h-1 mb-3 rounded-full cursor-pointer appearance-none"
                    style={{
                      background: `linear-gradient(to right, #d946ef 0%, #d946ef ${(currentTime / duration) * 100}%, #4a4a4a ${(currentTime / duration) * 100}%, #4a4a4a 100%)`
                    }}
                  />

                  <div className="flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <button onClick={togglePlay} className="text-white hover:text-primary transition-colors">
                        {isPlaying ? <Pause size={24} /> : <Play size={24} />}
                      </button>

                      <button onClick={toggleMute} className="text-white hover:text-primary transition-colors">
                        {isMuted ? <VolumeX size={24} /> : <Volume2 size={24} />}
                      </button>

                      <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.1"
                        value={volume}
                        onChange={handleVolumeChange}
                        className="w-20 h-1 rounded-full cursor-pointer appearance-none"
                        style={{
                          background: `linear-gradient(to right, #d946ef 0%, #d946ef ${volume * 100}%, #4a4a4a ${volume * 100}%, #4a4a4a 100%)`
                        }}
                      />

                      <span className="text-white text-sm">
                        {formatDuration(Math.floor(currentTime))} / {formatDuration(Math.floor(duration))}
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <button
                          onClick={() => setShowSpeedMenu(!showSpeedMenu)}
                          className="text-white hover:text-primary transition-colors flex items-center gap-1"
                        >
                          <Settings size={24} />
                          <span className="text-sm">{playbackSpeed}x</span>
                        </button>
                        {showSpeedMenu && (
                          <div className="absolute bottom-full right-0 mb-2 bg-secondary rounded-lg shadow-xl py-2 min-w-24 border border-primary/20">
                            {[0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2].map((speed) => (
                              <button
                                key={speed}
                                onClick={() => handleSpeedChange(speed)}
                                className={`block w-full px-4 py-2 text-left text-white hover:bg-primary transition-colors ${
                                  playbackSpeed === speed ? 'bg-primary' : ''
                                }`}
                              >
                                {speed}x
                              </button>
                            ))}
                          </div>
                        )}
                      </div>

                      <button onClick={toggleFullscreen} className="text-white hover:text-primary transition-colors">
                        {isFullscreen ? <Minimize size={24} /> : <Maximize size={24} />}
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-6">
                <h1 className="text-3xl md:text-4xl font-serif font-bold text-white mb-4">
                  {video.title}
                </h1>
                <div className="flex flex-wrap items-center gap-4 text-text-secondary mb-4">
                  <span>{formatViews(video.views)} views</span>
                  <span>•</span>
                  <span>{video.likes} likes</span>
                  <span>•</span>
                  <span className="px-3 py-1 bg-secondary rounded text-primary border border-primary">
                    {video.category}
                  </span>
                </div>
                <p className="text-text-secondary text-lg mb-6 leading-relaxed">
                  {video.description}
                </p>
                <div className="flex flex-wrap gap-2">
                  {video.tags.map((tag, idx) => (
                    <span
                      key={idx}
                      className="px-3 py-1 rounded border border-primary text-primary cursor-pointer hover:bg-primary hover:text-white transition-colors"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="lg:col-span-1">
              <h3 className="text-2xl font-serif font-bold text-white mb-4">Related Videos</h3>
              <div className="space-y-4">
                {relatedVideos.map((relVideo) => (
                  <div
                    key={relVideo.id}
                    onClick={() => onVideoSelect(relVideo)}
                    className="flex gap-3 cursor-pointer group"
                  >
                    <div className="relative w-40 flex-shrink-0">
                      <img
                        src={relVideo.thumbnailUrl}
                        alt={relVideo.title}
                        className="w-full h-24 object-cover rounded"
                      />
                      <div className="absolute bottom-1 right-1 px-1 py-0.5 bg-black/80 rounded text-xs text-white">
                        {formatDuration(relVideo.duration)}
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-white text-sm font-medium line-clamp-2 group-hover:text-primary transition-colors">
                        {relVideo.title}
                      </h4>
                      <p className="text-text-secondary text-xs mt-1">
                        {formatViews(relVideo.views)} views
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoPlayer;