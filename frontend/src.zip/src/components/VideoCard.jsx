import React, { useState } from 'react';
import { Play } from 'lucide-react';
import { formatDuration, formatViews } from '../utils/helpers';

const VideoCard = ({ video, onClick }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className="group cursor-pointer transition-all duration-300"
      style={{
        transform: isHovered ? 'scale(1.02)' : 'scale(1)',
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={() => onClick(video)}
    >
      <div className="relative overflow-hidden rounded-lg bg-secondary" style={{ aspectRatio: '16/9' }}>
        <img
          src={video.thumbnailUrl}
          alt={video.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-300 flex items-center justify-center">
          <Play 
            className="text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300 drop-shadow-lg" 
            size={48} 
          />
        </div>
        <div className="absolute bottom-2 right-2 px-2 py-1 bg-black/80 rounded text-xs text-white font-medium">
          {formatDuration(video.duration)}
        </div>
        {video.quality && video.quality.includes('4K') && (
          <div className="absolute top-2 left-2 px-2 py-1 bg-primary/80 rounded text-xs text-white font-bold">
            4K
          </div>
        )}
      </div>
      <div className="mt-3">
        <h3 className="text-white font-serif text-lg font-semibold line-clamp-2 group-hover:text-primary transition-colors">
          {video.title}
        </h3>
        <div className="mt-1 flex items-center gap-2 text-sm text-text-secondary">
          <span>{formatViews(video.views)} views</span>
          <span>•</span>
          <span>{video.likes} likes</span>
        </div>
        <div className="mt-2 flex flex-wrap gap-2">
          {video.tags.slice(0, 3).map((tag, idx) => (
            <span
              key={idx}
              className="px-2 py-1 text-xs rounded border border-primary text-primary hover:bg-primary hover:text-white transition-colors cursor-pointer"
            >
              #{tag}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default VideoCard;