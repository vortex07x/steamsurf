import React from 'react';

const HeroSection = () => {
  return (
    <div className="relative h-[60vh] flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/50 to-black z-10" />
      <div className="absolute inset-0 bg-dark">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-secondary rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
        </div>
      </div>
      <div className="relative z-20 text-center px-4">
        <h2 className="text-5xl md:text-7xl font-serif font-bold mb-6 text-white">
          Discover Amazing Videos
        </h2>
        <p className="text-xl md:text-2xl text-text-secondary mb-8">
          Your premium video surfing experience starts here
        </p>
        <button className="btn-primary glow-primary text-lg px-8 py-4">
          Start Exploring
        </button>
      </div>
    </div>
  );
};

export default HeroSection;