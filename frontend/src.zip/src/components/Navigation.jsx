import React, { useState, useEffect } from 'react';
import { Search, Menu } from 'lucide-react';

const Navigation = ({ onSearchClick }) => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav 
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        scrolled ? 'bg-black/80 backdrop-blur-lg shadow-lg' : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center gap-8">
            <h1 className="text-4xl font-serif font-bold text-gradient cursor-pointer">
              StreamSurf
            </h1>
            <div className="hidden md:flex items-center gap-6">
              <a href="#" className="nav-link">Videos</a>
              <a href="#" className="nav-link">Browse</a>
              <a href="#" className="nav-link">Categories</a>
              <a href="#" className="nav-link">About</a>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={onSearchClick}
              className="p-2 text-text-primary hover:text-primary transition-colors"
            >
              <Search size={24} />
            </button>
            <button className="md:hidden p-2 text-text-primary hover:text-primary transition-colors">
              <Menu size={24} />
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;