const API_BASE_URL = 'http://localhost:5000/api';

// Fetch all videos
export const fetchVideos = async () => {
  try {
    const response = await fetch(`${API_BASE_URL}/videos`);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error fetching videos:', error);
    throw error;
  }
};

// Fetch single video by ID
export const fetchVideoById = async (id) => {
  try {
    const response = await fetch(`${API_BASE_URL}/videos/${id}`);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error fetching video:', error);
    throw error;
  }
};

// Search videos
export const searchVideos = async (query) => {
  try {
    const response = await fetch(`${API_BASE_URL}/videos/search?q=${encodeURIComponent(query)}`);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error searching videos:', error);
    throw error;
  }
};

// Filter videos by category
export const filterByCategory = async (category) => {
  try {
    const response = await fetch(`${API_BASE_URL}/videos?category=${encodeURIComponent(category)}`);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error filtering videos:', error);
    throw error;
  }
};