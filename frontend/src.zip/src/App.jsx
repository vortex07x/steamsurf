import React, { useState } from 'react';
import HomePage from './pages/HomePage';
import VideoPlayer from './components/VideoPlayer';

function App() {
  const [selectedVideo, setSelectedVideo] = useState(null);
  const [allVideos, setAllVideos] = useState([]);

  const handleVideoSelect = (video) => {
    setSelectedVideo(video);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const getRelatedVideos = (currentVideo) => {
    if (!allVideos.length) return [];
    
    return allVideos
      .filter(v => v.id !== currentVideo.id && 
              (v.category === currentVideo.category || 
               v.tags.some(tag => currentVideo.tags.includes(tag))))
      .slice(0, 5);
  };

  // Pass setAllVideos to HomePage so it can populate the videos
  React.useEffect(() => {
    const fetchAllVideos = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/videos');
        const data = await response.json();
        setAllVideos(data);
      } catch (error) {
        console.error('Error fetching videos:', error);
      }
    };
    fetchAllVideos();
  }, []);

  if (selectedVideo) {
    return (
      <VideoPlayer
        video={selectedVideo}
        onClose={() => setSelectedVideo(null)}
        relatedVideos={getRelatedVideos(selectedVideo)}
        onVideoSelect={handleVideoSelect}
      />
    );
  }

  return <HomePage onVideoSelect={handleVideoSelect} />;
}

export default App;